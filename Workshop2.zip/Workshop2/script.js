const form = document.getElementById('form');
const message = document.getElementById('display');

form.addEventListener('submit', function (e) {
    e.preventDefault();
    const inputs = document.getElementsByClassName('input');
    let allFilled = true;

    for (let i = 0; i < inputs.length; i++) {
        if (inputs[i].value.trim() === "") {
            allFilled = false;
            break;
        }
    }

    if (allFilled) {
        message.innerText = "Congratulations, Form Submitted.";
        message.style.color = "green";
    } else {
        message.innerText = "You need to fill all the fields to submit.";
        message.style.color = "red";
    }
});



const menuButton = document.getElementById('menu-button');
const navLinks = document.querySelector('.link');

function toggleMenu() {
    // 1. Toggle the CSS class (controls visibility via CSS)
    navLinks.classList.toggle('open');

    // 2. Update the button text/icon for accessibility
    const isExpanded = navLinks.classList.contains('open');
    menuButton.setAttribute('aria-expanded', isExpanded);
    menuButton.innerHTML = isExpanded ? '✕' : '☰'; // X vs Hamburger
}

// Add the event handler
menuButton.addEventListener('click', toggleMenu);

// OPTIONAL: Close the menu when a link inside is clicked (for mobile UX)
navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
        if (navLinks.classList.contains('open')) {
            toggleMenu(); // Closes the menu
        }
    });
});